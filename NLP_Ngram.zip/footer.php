<!-- Footer -->
<!-- Javascripts -->
<script src="assets/javascripts/jquery.min.js" type="text/javascript"></script>
<script src="assets/javascripts/jquery-ui.min.js" type="text/javascript"></script>
<script src="assets/javascripts/modernizr.min.js" type="text/javascript"></script>
<script src="assets/javascripts/application-985b892b.js" type="text/javascript"></script>
<!-- Google Analytics -->
<script>
  var _gaq=[['_setAccount','UA-XXXXX-X'],['_trackPageview']];
  (function(d,t){var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
  g.src=('https:'==location.protocol?'//ssl':'//www')+'.google-analytics.com/ga.js';
  s.parentNode.insertBefore(g,s)}(document,'script'));
</script>